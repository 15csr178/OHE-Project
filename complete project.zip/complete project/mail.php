<?php
//echo "hai";
				 //echo $kongumail;

  require 'PHPMailer/PHPMailerAutoload.php';
             
                    $email = "sampathvaduga@gmail.com";                    
                    $password = "sam#1201";
                   
				   
				   
				   function generateRandomString($length = 8) {
    return substr(str_shuffle(str_repeat($x='0123456789G', ceil($length/strlen($x)) )),1,$length);
}
$str=generateRandomString();
 #replace with your mailid and password in this id.php file
				 $to_id = "$kongumail";
				 //echo $str;
				 //echo "hai";
				 $message="<html>
				 <h3 style=color:green;>Your new password is 	:'$str'</h3></html>";
                    $subject = "Password Reset";

                    $mail = new PHPMailer;

                    $mail->isSMTP();

                    $mail->Host = 'smtp.gmail.com';

                    $mail->Port = 587;

                    $mail->SMTPSecure = 'tls';

                    $mail->SMTPAuth = true;

                    $mail->Username = $email;

                    $mail->Password = $password;

                    $mail->setFrom('from@example.com', 'Password Reset');

                    $mail->addReplyTo('dontreply@gmail.com', 'auto generated mail');

                    $mail->addAddress($to_id);
//echo $to_id;
                    $mail->Subject = $subject;

                    $mail->msgHTML($message);

                    if (!$mail->send()) {
                       $error = "Mailer Error: " . $mail->ErrorInfo;
                        ?><script>alert('<?php echo $error ?>');</script><?php
                    } 
                    else {
                       echo '<script>alert("New Password Send To Your Email Id !");</script>';
                    }
					?>
					