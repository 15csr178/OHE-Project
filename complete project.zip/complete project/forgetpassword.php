<?php
$db_server='localhost';
$db_user='root';
$db_pass='';
$db_name='ohe';
$response=array();

$connection=mysqli_connect($db_server,$db_user,$db_pass);
if($connection)
{
	//echo "conn";
}
else{
	echo "No conn";
}
$db=mysqli_select_db($connection,$db_name);
if($db)
{
	//echo "database";
}
else{
	echo "No db";
}

$kongumail=$_POST['mail'];
$rollno=$_POST['rollno'];
//echo $kongumail;
//echo $rollno;

if($_SERVER['REQUEST_METHOD']==='POST')
{
//$query12=mysqli_query($connection,"INSERT INTO `regi` ( `rollno`,`password` )VALUES ('$username','$password');");	

$query12=mysqli_query($connection,"SELECT * FROM `register` WHERE kongumail LIKE '$kongumail' and rollno LIKE '$rollno';");	
//echo "sushanth";
if($query12)
{
		$result=mysqli_fetch_assoc($query12);
		//echo $result;
		$response['rollno']=$result['rollno'];
		
		if($response['rollno'])
		{//echo "  ";
	
		
		
					include("mail.php");
					include("mailpsupdate.php");
					//echo '<script>alert("New Password Send To Your Email Id !");</script>';
					
					
		}
		else
		{echo '<script>alert("Enter Correct Kongu.edu Mail And RollNo");</script>';
		include("forgetpassword.html");
		
		}
}
else
{
	echo "enter valid";
}
	
}
else
{
	echo 'server';
	
}
?>