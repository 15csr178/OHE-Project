<?php
$db_server='localhost';
$db_user='root';
$db_pass='';
$db_name='ohe';
$response=array();

$connection=mysqli_connect($db_server,$db_user,$db_pass);
if($connection)
{
	//echo "conn";
}
else{
	echo "No conn";
}
$db=mysqli_select_db($connection,$db_name);
if($db)
{
	//echo "database";
}
else{
	echo "No db";
}


if($_SERVER['REQUEST_METHOD']==='POST')
{
$query12=mysqli_query($connection,"UPDATE register SET `authpassword` = '$str'  WHERE `rollno` LIKE '$rollno' ;");	
if($query12)
{
		//echo '<script>alert("New Password updated !");</script>';

		include("login.html");
		
}
else
{
	echo "enter valid";
}
}	

else
{
	echo 'server';
	
}
?>